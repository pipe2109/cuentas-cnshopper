"""Ejecutar: python -m unittest discover -s tests -v"""
import os
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
import database as database_module


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.data = os.path.join(self.tmp.name, 'data')
        self.backups = os.path.join(self.tmp.name, 'backups')
        self.dbpath = os.path.join(self.data, 'clients.db')
        self.patchers = [patch.object(database_module, 'DATA_DIR', self.data),
                         patch.object(database_module, 'BACKUP_DIR', self.backups),
                         patch.object(database_module, 'DB_PATH', self.dbpath)]
        for p in self.patchers:
            p.start()
            self.addCleanup(p.stop)

    def test_new_install(self):
        database_module.init_db()
        with database_module.db() as con:
            self.assertEqual(con.execute('SELECT count(*) FROM clients').fetchone()[0], 0)
            self.assertEqual(con.execute('PRAGMA user_version').fetchone()[0], 4)

    def test_v3_migration_preserves_records(self):
        os.makedirs(self.data)
        with sqlite3.connect(self.dbpath) as con:
            con.execute('''CREATE TABLE clients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
                contact TEXT NOT NULL DEFAULT '', email TEXT DEFAULT '', phone TEXT DEFAULT '',
                status TEXT DEFAULT 'Pendiente', notes TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
            con.execute('''CREATE TABLE client_history (id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL,
                action TEXT NOT NULL, details TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
            con.execute("INSERT INTO clients(name,contact,email,notes) VALUES ('Prueba','prueba@ejemplo.com','prueba@ejemplo.com','Nota V3')")
            con.execute("INSERT INTO client_history(client_id,action) VALUES (1,'Ficha creada')")
        database_module.init_db()
        with database_module.db() as con:
            self.assertEqual(con.execute('SELECT notes FROM clients WHERE id=1').fetchone()[0], 'Nota V3')
            self.assertEqual(con.execute('SELECT action FROM client_history').fetchone()[0], 'Ficha creada')
        self.assertTrue(os.listdir(self.backups))
        attempt = database_module.start_registration(1)
        with self.assertRaises(ValueError):
            database_module.start_registration(1)
        database_module.change_registration(attempt, 'Esperando OTP', 'Esperando al titular')
        database_module.change_registration(attempt, 'Completado', 'Titular confirmó')
        with database_module.db() as con:
            self.assertEqual(con.execute('SELECT status FROM clients WHERE id=1').fetchone()[0], 'Completado')
            self.assertEqual(con.execute('SELECT count(*) FROM client_history').fetchone()[0], 4)

    def test_requires_email(self):
        database_module.init_db()
        with database_module.db() as con:
            con.execute("INSERT INTO clients(name,contact) VALUES ('Sin correo','123')")
        with self.assertRaises(ValueError):
            database_module.start_registration(1)


if __name__ == '__main__':
    unittest.main()
