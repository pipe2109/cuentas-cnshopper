import unittest
from unittest.mock import MagicMock, patch
from browser_worker import navigate_to_registration, assist_form, registration_email_field

class NavigationTests(unittest.TestCase):
    def test_no_email_fill_on_homepage(self):
        page = MagicMock()
        page.url = 'https://cnshopper.com/'
        self.assertFalse(assist_form(page, '', 'a@example.com', ''))
        page.locator.assert_not_called()

    @patch('browser_worker.click_visible_unique', return_value=True)
    def test_desktop_clicks_register(self, click):
        page = MagicMock()
        page.url = 'https://cnshopper.com/register'
        page.get_by_placeholder.return_value.count.return_value = 1
        self.assertTrue(navigate_to_registration(page, 'desktop'))
        self.assertEqual(click.call_count, 1)

    @patch('browser_worker.click_visible_unique', return_value=True)
    def test_mobile_clicks_me_and_sign_up(self, click):
        page = MagicMock()
        page.url = 'https://cnshopper.com/register'
        page.get_by_placeholder.return_value.count.return_value = 1
        self.assertTrue(navigate_to_registration(page, 'mobile'))
        self.assertEqual(click.call_count, 2)

    @patch('browser_worker.click_visible_unique', return_value=False)
    def test_failed_navigation_does_not_submit(self, click):
        page = MagicMock()
        self.assertFalse(navigate_to_registration(page, 'desktop'))
        page.get_by_placeholder.assert_not_called()

if __name__ == '__main__':
    unittest.main()
