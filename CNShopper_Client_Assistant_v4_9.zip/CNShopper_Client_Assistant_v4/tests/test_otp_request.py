import unittest
from unittest.mock import MagicMock, patch
from browser_worker import send_verification_once

class OtpRequestTests(unittest.TestCase):
    @patch('browser_worker.find_email_field')
    def test_never_click_on_wrong_email(self, find):
        page = MagicMock(url='https://cnshopper.com/register')
        find.return_value.input_value.return_value = 'other@example.com'
        self.assertFalse(send_verification_once(page, 'allowed@example.com'))
        page.get_by_role.assert_not_called()

    def test_never_click_outside_register(self):
        page = MagicMock(url='https://cnshopper.com/')
        self.assertFalse(send_verification_once(page, 'a@example.com'))
        page.get_by_role.assert_not_called()

    @patch('browser_worker.find_email_field')
    def test_click_once_when_authorized(self, find):
        page = MagicMock(url='https://cnshopper.com/register')
        find.return_value.input_value.return_value = 'allowed@example.com'
        button = page.get_by_role.return_value
        button.count.return_value = 1
        button.first.is_visible.return_value = True
        button.first.is_enabled.return_value = True
        self.assertTrue(send_verification_once(page, 'allowed@example.com'))
        button.first.click.assert_called_once()

if __name__ == '__main__':
    unittest.main()
