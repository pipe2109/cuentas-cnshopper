import unittest
from unittest.mock import patch, MagicMock
import browser_session
from browser_worker import fill_if_unique

class BrowserTests(unittest.TestCase):
    @patch.object(browser_session, 'subprocess')
    @patch.object(browser_session, 'threading')
    def test_temporary_browser_arguments(self, threading, subprocess):
        subprocess.Popen.return_value = MagicMock()
        self.assertTrue(browser_session.launch_browser('mobile', {'name':'Prueba', 'email':'a@example.com'}))
        cmd = subprocess.Popen.call_args.args[0]
        self.assertEqual(cmd[2], 'mobile')
        self.assertIn('invite_id=2370842', cmd[3])
        self.assertEqual(cmd[4:6], ['Prueba', 'a@example.com'])
        self.assertNotIn('browser_profile', str(cmd))
        threading.Thread.return_value.start.assert_called_once()

    def test_ambiguous_fields_are_not_filled(self):
        page = MagicMock()
        page.locator.return_value.count.return_value = 2
        self.assertFalse(fill_if_unique(page, ['input[type=email]'], 'a@example.com'))
        page.locator.return_value.first.fill.assert_not_called()

    def test_empty_unique_field_filled(self):
        page = MagicMock()
        field = page.locator.return_value.first
        page.locator.return_value.count.return_value = 1
        field.is_visible.return_value = True
        field.is_enabled.return_value = True
        field.input_value.return_value = ''
        self.assertTrue(fill_if_unique(page, ['input[type=email]'], 'a@example.com'))
        field.fill.assert_called_once()

if __name__ == '__main__':
    unittest.main()
