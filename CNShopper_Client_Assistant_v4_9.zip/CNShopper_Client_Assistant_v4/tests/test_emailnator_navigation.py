import unittest
from unittest.mock import Mock, patch
from browser_worker import open_emailnator_for_manual_review, dismiss_emailnator_cookie_notice

class EmailnatorNavigationTests(unittest.TestCase):
    def make_tab(self):
        tab, context = Mock(), Mock()
        context.new_page.return_value = tab
        button = tab.get_by_role.return_value
        button.count.return_value = 0
        consent = Mock()
        consent.count.return_value = 0
        custom = Mock()
        custom.count.return_value = 1
        custom.first.is_visible.return_value = True
        tab.get_by_text.side_effect = lambda value, exact=False: custom if value == 'Custom email' else consent
        field = tab.get_by_placeholder.return_value
        field.count.return_value = 1
        field.is_enabled.return_value = True
        field.input_value.return_value = ''
        return tab, context, button, consent, custom, field

    def test_custom_email_exact_and_no_submit(self):
        tab, context, button, consent, custom, field = self.make_tab()
        with patch('browser_worker.dismiss_emailnator_cookie_notice'):
            self.assertIs(open_emailnator_for_manual_review(context, 'example@example.com'), tab)
        custom.first.click.assert_called_once_with(timeout=4000)
        field.fill.assert_called_once_with('example@example.com', timeout=3500)
        tab.get_by_text.assert_any_call('Custom email', exact=True)
        self.assertFalse(tab.get_by_role.called)

    def test_cookie_button_closed(self):
        tab, _, button, *_ = self.make_tab()
        button.count.return_value = 1
        button.first.is_visible.return_value = True
        self.assertTrue(dismiss_emailnator_cookie_notice(tab))
        button.first.click.assert_called_once_with(timeout=3500)

    def test_cookie_text_fallback(self):
        tab, _, button, consent, *_ = self.make_tab()
        consent.count.return_value = 1
        consent.first.is_visible.return_value = True
        self.assertTrue(dismiss_emailnator_cookie_notice(tab))
        consent.first.click.assert_called_once_with(timeout=3500)

    def test_missing_link_does_not_click_other_buttons(self):
        tab, context, button, consent, custom, field = self.make_tab()
        custom.count.return_value = 0
        with patch('browser_worker.dismiss_emailnator_cookie_notice'):
            self.assertIs(open_emailnator_for_manual_review(context, 'test@example.com'), tab)
        self.assertFalse(custom.first.click.called)
        self.assertFalse(field.fill.called)

if __name__ == '__main__':
    unittest.main()
